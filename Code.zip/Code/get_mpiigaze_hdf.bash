#!/bin/bash

cd datasets

# MPIIGaze dataset with 60x36 greyscale eye images
wget -Nnv https://ait.ethz.ch/projects/2018/pictorial-gaze/downloads/MPIIGaze.h5
